package id.github.bagaswirapradana.moovie.activities.detail;

import android.support.v7.app.AppCompatActivity;

import com.pierfrancescosoffritti.androidyoutubeplayer.player.YouTubePlayerView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import id.github.bagaswirapradana.moovie.R;

@EActivity(R.layout.activity_detail_movie)
public class DetailMovieActivity extends AppCompatActivity implements IDetailMovieView{

    @AfterViews
    void initialize(){
        setYoutubePlayerView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void setYoutubePlayerView() {

    }
}
