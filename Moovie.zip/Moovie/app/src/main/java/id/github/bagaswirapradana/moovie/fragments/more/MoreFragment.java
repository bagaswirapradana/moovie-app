package id.github.bagaswirapradana.moovie.fragments.more;

import android.support.v4.app.Fragment;

import org.androidannotations.annotations.EFragment;

import id.github.bagaswirapradana.moovie.R;

@EFragment(R.layout.fragment_more)
public class MoreFragment extends Fragment {
}
