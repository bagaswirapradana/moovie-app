package id.github.bagaswirapradana.moovie.fragments.more;

public class MorePresenter {
}
