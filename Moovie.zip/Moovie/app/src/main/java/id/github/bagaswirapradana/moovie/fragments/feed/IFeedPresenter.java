package id.github.bagaswirapradana.moovie.fragments.feed;

public interface IFeedPresenter {
    void getFeedData();
    void onDestroy();
}
