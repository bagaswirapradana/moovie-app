package id.github.bagaswirapradana.moovie.activities.detail;

public interface IDetailMovieView {
    void setYoutubePlayerView();
}
