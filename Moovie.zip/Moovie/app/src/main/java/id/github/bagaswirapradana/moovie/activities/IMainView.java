package id.github.bagaswirapradana.moovie.activities;

import android.support.v4.app.Fragment;

public interface IMainView {
    void loadFragment(Fragment fragment);
    void initToolbar();
    void setNavigationBehavior();
}
