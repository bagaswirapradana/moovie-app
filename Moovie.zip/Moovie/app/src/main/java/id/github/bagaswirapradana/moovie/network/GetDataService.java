package id.github.bagaswirapradana.moovie.network;

import id.github.bagaswirapradana.moovie.model.Feed;
import id.github.bagaswirapradana.moovie.model.PopularMovie;
import id.github.bagaswirapradana.moovie.model.TopRatedMovie;
import id.github.bagaswirapradana.moovie.model.UpComingMovie;
import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface GetDataService {

    @GET("trending/all/day")
    Observable<Feed> getDataFeed(@Query("api_key") String api_key);

    @GET("movie/popular")
    Observable<PopularMovie> getDataPopularMovie(@Query("api_key") String api_key, @Query("language") String language);

    @GET("movie/top_rated")
    Observable<TopRatedMovie> getDataTopRatedMovie(@Query("api_key") String api_key, @Query("language") String language);

    @GET("movie/upcoming")
    Observable<UpComingMovie> getDataUpComingMovie(@Query("api_key") String api_key, @Query("language") String language);
}
